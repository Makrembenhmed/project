
const { author } = require("../Models/author.Model")

module.exports.test = (req, res) => {

    res.json("the server Says hello MERN Stack : app Authors")
}

// all authors

module.exports.findAllAuthors = (req, res) => {

    author.find()
        .then(AllAuthors => {
            console.log(AllAuthors)
            res.json(AllAuthors)
        })
        .catch(err => { res.json({ message: "wait a minute 😏😏 " }) })
    }


    // Create new Author

    module.exports.createNewauthor = (req, res) => {

        author.create(req.body)
            .then(Createauthor => {
                console.log(Createauthor)
                res.status(200).json({ Createauthor })
            
            })
            .catch((err) => { res.status(400).json({err}) })
    
    
    }
    
//? findOne

module.exports.getOneAuthor = (req, res) => {

    author.findOne({ _id: req.params.a_id })
        .then(OneAuthor => {
            console.log(OneAuthor)
            res.json({ OneAuthor })
        })
        .catch(err => { res.status(400).json({ message: "wait a minute 😏😏 ", error: err }) })

}

//? UPDATE
module.exports.UpdateAuthor = (req, res) => {
    author.findOneAndUpdate(
        { _id: req.params.a_id },
        req.body,
        { new: true, runValidators: true }

    )
        .then(UpdatedAuthor => {
            console.log(UpdatedAuthor)
            res.json({ UpdatedAuthor })
        })
        .catch(err => { res.status(400).json({ err }) })

}

//? DELETE
module.exports.DeleteOneAuthor = (req, res) => {
    author.deleteOne({ _id: req.params.a_id })
        .then(deleteAuthor => {
            console.log(deleteAuthor)
            res.json({ deleteAuthor })
        })
        .catch(err => { res.status(400).json({ message: "wait a minute 😏😏 ", error: err }) })

}