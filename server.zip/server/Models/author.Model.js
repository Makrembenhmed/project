const mongoose = require("mongoose")



const authortestSchema = new mongoose.Schema({
    
    namelastname: {

        type: String,
        required: [true, " name of Author is Required"],
        minLength: [3, "min length must be greater than 3"],
    }
}, { timestamps: true })


module.exports.author= mongoose.model("author", authortestSchema)

