
const authorControllers = require("../Controllers/author.Controllers")

module.exports = (app) => {

    app.get("/api/test", authorControllers.test)

    

    
    app.get("/api/author", authorControllers.findAllAuthors)
    app.get("/api/author/:a_id", authorControllers.getOneAuthor)
    app.post("/api/author", authorControllers.createNewauthor)
    app.put("/api/author/:a_id", authorControllers.UpdateAuthor)
    app.delete("/api/author/:a_id", authorControllers.DeleteOneAuthor)
}

