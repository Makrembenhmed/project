
import React, { useState } from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'

export const NewAuthor = () => {

    

    const[namelastname,setnamelastname]=useState("")
    const [errors, setErrors] = useState({})
    const submithandler=(e)=>{
        e.preventDefault()
        const newauthor={
            namelastname,
            
        }
        axios.post("http://localhost:8002/api/author",newauthor)
            .then(res=>{
                console.log(res)

                
                
                setnamelastname("")
                
            })
          
      .catch((err) => {
        console.log(err.response.data.err.errors);
        setErrors(err.response.data.err.errors);
      });
    }
    


    return (
        <div class='container'>
        
        <h3><Link  to='/'>Home</Link></h3>
            
       
                <form onSubmit={submithandler} >
                <fieldset >
                <legend class="App-colortext"> Add a new author :</legend>
                <div class="form-group">
                <label >  Name</label> <br/>
                <input onChange={(e)=>{setnamelastname(e.target.value)}} value={namelastname} class="form control"/><br></br>

                {errors.namelastname ? <p style={{color:"red"}}>{errors.namelastname.message}</p> : null}

                </div>
                
                <div class='form-inline'>
                <div>
                 <Link to={('/')} class="btn btn-primary">Concel</Link> 
               </div>
                <div>
                <input type='submit' value={"Submit"} class="btn btn-primary ml-2" />
                </div>
                </div>
                </fieldset>
                </form>
            

        </div>
    )
}