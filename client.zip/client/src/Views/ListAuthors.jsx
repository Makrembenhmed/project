
import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

export const ListAuthors = () => {
    const [refrech,setrefrech]=useState(false)

    const updatelist=()=>{setrefrech(!refrech)}
    
    const [AllAuthors,setAllAuthors]=useState([])

      
const deletedata=(auth_id)=>{
    axios.delete(`http://localhost:8002/api/author/${auth_id}`)
    .then(res=>{console.log(res)
        console.log(" succes deleting author")
        updatelist()
        
    })
    .catch(err=>{console.log(" erreur deleting author",err.response)})
}

    useEffect(()=>{
        axios.get('http://localhost:8002/api/author')
        .then(res=>{
            console.log(res.data)
            setAllAuthors(res.data)
        })
        .catch(err=>{})


    },[refrech])


    return (
        <div class="container" >
        <h3> <Link to='/new'> Add an Author</Link></h3>
        <h2 class="App-colortext">we have quotes by :</h2>

        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th scope="col">Add An Author</th>
                    <th scope="col">Action Available</th>
                </tr>
            </thead>
            <tbody>

                {
                  
                AllAuthors.map((author)=>{
                    return (
                <tr>
      
     
                    <td>{author.namelastname}</td>
                    <td >      
                        <div class="btn-group">                  
                    <Link to={('/edit/'+author._id)} style={{color:"white"}} class="btn btn-secondary btn-sm">Edit</Link>
                    
                    <button onClick={ (e)=>{deletedata(author._id)}  }   style={{marginLeft:10}} class="btn btn-dark"> delete </button>
                    </div>      
                    </td>
                </tr>)
                
                })
                }
            </tbody>
        </table>

<br />
<br />
          

        </div>
    )
}