
import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link,  useNavigate,  useParams } from 'react-router-dom'

export const UpdateAuthor = () => {

    const [errors, setErrors] = useState({});
  const [authorNotFoundError, setAuthorNotFoundError] = useState("");

    const {author_id}=useParams()
    
    const[namelastname,setnamelastname]=useState("")
    const navigate=useNavigate()


    
    useEffect(()=>{
        axios.get(`http://localhost:8002/api/author/${author_id}`)
        .then(res=>{ 
            console.log(res.data)
            const {namelastname}=res.data.OneAuthor
            setnamelastname(namelastname)

        })
        .catch(err=>{console.log(err)
            setAuthorNotFoundError(`Author not found using that ID`);
        })


    },[]);



    

    const updatehandler=(e)=>{
        e.preventDefault()
        const editauthor={
            namelastname,
            
        }
        axios.put(`http://localhost:8002/api/author/${author_id}`,editauthor)
            .then(res=>{
                console.log(res)                                
                navigate('/')
            })
            .catch(err=>{console.log(err)
                console.log(err.response.data.err.errors)
                setErrors(err.response.data.err.errors)
            })

    }

    return (
        
        <div class='container'>
        
        <h3><Link to='/'>Home</Link></h3>
            
       
            
        <form onSubmit={updatehandler} >
            {authorNotFoundError ? (
        <h2>
          {authorNotFoundError} <Link to="/new">Click here to add author</Link>
        </h2>
      ) : null}

                <fieldset >
                <legend class="App-colortext"> Edit author :</legend>
                <div class="form-group">
                <label >  Name</label> <br/>
                <input onChange={(e)=>{setnamelastname(e.target.value)}} value={namelastname} class="form control"/><br></br>
                {errors.namelastname ? <p>{errors.namelastname.message}</p> : null}
                </div>
                <div class='form-inline'>
                <div>
               <button class="btn btn-primary "  > Concel <Link to={('/')}></Link> </button>
               </div>
                <div>
                <input type='submit' value={"Submit"} class="btn btn-primary ml-2" />
                </div>
                </div>
                </fieldset>
                </form>
            

        </div>
 
    )
}