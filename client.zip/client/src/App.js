
import { Route, Routes } from 'react-router-dom';
import './App.css';
import { NewAuthor } from './Views/NewAuthor';
import { ListAuthors } from './Views/ListAuthors';
import { UpdateAuthor } from './Views/UpdateAuthor';

function App() {
  return (
    <div class="App"  >
    <h1 class="container"> Favorite authors</h1>
    <Routes>
    <Route path='/new' element={<NewAuthor/>}/>
    <Route path='/' element={<ListAuthors/>}/>
    <Route path='/edit/:author_id' element={<UpdateAuthor/>}/>
    </Routes>
    </div>
  );
}

export default App;
